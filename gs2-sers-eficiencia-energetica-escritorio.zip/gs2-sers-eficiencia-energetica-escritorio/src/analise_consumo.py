"""
Análise de Consumo de Energia - Escritório
GS2-SERS - Eficiência Energética
"""

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# Configuração de caminhos
BASE_DIR = Path(__file__).parent.parent
DADOS_DIR = BASE_DIR / "dados"
GRAFICOS_DIR = BASE_DIR / "graficos"

# Criar diretório de gráficos se não existir
GRAFICOS_DIR.mkdir(exist_ok=True)


def carregar_dados():
    """Carrega os dados de consumo de energia."""
    arquivo_csv = DADOS_DIR / "consumo_energia_escritorio.csv"
    
    if not arquivo_csv.exists():
        print(f"Arquivo não encontrado: {arquivo_csv}")
        return None
    
    df = pd.read_csv(arquivo_csv, parse_dates=['data'])
    return df


def analisar_consumo(df):
    """Realiza análise básica do consumo."""
    if df is None:
        return
    
    print("=== Análise de Consumo de Energia ===\n")
    print(f"Período: {df['data'].min()} a {df['data'].max()}")
    print(f"Total de registros: {len(df)}")
    print(f"\nEstatísticas de Consumo (kWh):")
    print(df['consumo_kwh'].describe())
    print(f"\nConsumo médio por hora: {df['consumo_kwh'].mean():.2f} kWh")
    print(f"Consumo total: {df['consumo_kwh'].sum():.2f} kWh")


def gerar_grafico_consumo_diario(df):
    """Gera gráfico de consumo diário."""
    if df is None:
        return
    
    plt.figure(figsize=(12, 6))
    plt.plot(df['hora'], df['consumo_kwh'], marker='o', linewidth=2)
    plt.xlabel('Hora do Dia')
    plt.ylabel('Consumo (kWh)')
    plt.title('Consumo Diário de Energia - Escritório')
    plt.grid(True, alpha=0.3)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    arquivo_grafico = GRAFICOS_DIR / "consumo_diario.png"
    plt.savefig(arquivo_grafico, dpi=300, bbox_inches='tight')
    print(f"\nGrágico salvo: {arquivo_grafico}")
    plt.close()


def gerar_grafico_economia(df):
    """Gera gráfico de estimativa de economia."""
    if df is None:
        return
    
    consumo_medio = df['consumo_kwh'].mean()
    meta_reducao = consumo_medio * 0.15  # Meta de 15% de redução
    
    categorias = ['Consumo Atual', 'Meta de Redução']
    valores = [consumo_medio, meta_reducao]
    cores = ['#ff6b6b', '#51cf66']
    
    plt.figure(figsize=(10, 6))
    plt.bar(categorias, valores, color=cores, alpha=0.8)
    plt.ylabel('Consumo (kWh)')
    plt.title('Estimativa de Economia de Energia - Meta de 15% de Redução')
    plt.grid(True, alpha=0.3, axis='y')
    
    # Adicionar valores nas barras
    for i, v in enumerate(valores):
        plt.text(i, v + 0.5, f'{v:.2f} kWh', ha='center', va='bottom')
    
    plt.tight_layout()
    
    arquivo_grafico = GRAFICOS_DIR / "economia_estimativa.png"
    plt.savefig(arquivo_grafico, dpi=300, bbox_inches='tight')
    print(f"Gráfico salvo: {arquivo_grafico}")
    plt.close()


def main():
    """Função principal."""
    print("Iniciando análise de consumo de energia...\n")
    
    # Carregar dados
    df = carregar_dados()
    
    if df is not None:
        # Análise
        analisar_consumo(df)
        
        # Gerar gráficos
        print("\nGerando gráficos...")
        gerar_grafico_consumo_diario(df)
        gerar_grafico_economia(df)
        
        print("\nAnálise concluída!")
    else:
        print("Erro ao carregar dados.")


if __name__ == "__main__":
    main()

